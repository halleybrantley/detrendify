#ifndef __GETDk__
#define __GETDk__


arma::sp_mat get_D1(int n);

arma::sp_mat get_Dk(int n,
                    int k);
#endif // __GETDk__