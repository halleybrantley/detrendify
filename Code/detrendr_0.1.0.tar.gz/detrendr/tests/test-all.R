library(testthat)
load_all("detrendr") 
test_package("detrendr")